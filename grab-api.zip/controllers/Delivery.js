'use strict';

var utils = require('../utils/writer.js');
var Delivery = require('../service/DeliveryService');

module.exports.cancelDelivery = function cancelDelivery (req, res, next) {
  var deliveryID = req.swagger.params['deliveryID'].value;
  Delivery.cancelDelivery(deliveryID)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.getDelivery = function getDelivery (req, res, next) {
  var deliveryID = req.swagger.params['deliveryID'].value;
  Delivery.getDelivery(deliveryID)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.postDeliveries = function postDeliveries (req, res, next) {
  var deliveries = req.swagger.params['deliveries'].value;
  Delivery.postDeliveries(deliveries)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};

module.exports.postQuotes = function postQuotes (req, res, next) {
  var quote = req.swagger.params['quote'].value;
  Delivery.postQuotes(quote)
    .then(function (response) {
      utils.writeJson(res, response);
    })
    .catch(function (response) {
      utils.writeJson(res, response);
    });
};
