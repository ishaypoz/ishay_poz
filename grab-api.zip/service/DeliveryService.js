'use strict';


/**
 * Cancel a delivery
 *
 * deliveryID String the delivery id returned when delivery request was made
 * no response value expected for this operation
 **/
exports.cancelDelivery = function(deliveryID) {
  return new Promise(function(resolve, reject) {
    resolve();
  });
}


/**
 * Get the full information of a delivery
 *
 * deliveryID String the delivery id returned when delivery request was made
 * returns GetDelivery
 **/
exports.getDelivery = function(deliveryID) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Request for delivery service
 * origin, destination, sender and recipient are mandatory 
 *
 * deliveries Deliveries 
 * returns Delivery
 **/
exports.postDeliveries = function(deliveries) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = "";
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}


/**
 * Request for delivery service quotes
 * origin and destination are mandatory. When packages details aren\\'t provided, a single cheapest category package is assumed. Immediate dispatching is assumed. An array of delivery services with their respective quote is returned. 
 *
 * quote Quote 
 * returns Quotes
 **/
exports.postQuotes = function(quote) {
  return new Promise(function(resolve, reject) {
    var examples = {};
    examples['application/json'] = {
  "origin" : {
    "address" : "address",
    "keywords" : "keywords",
    "cityCode" : "cityCode",
    "coordinates" : {
      "latitude" : 5.962134,
      "longitude" : 5.637377
    }
  },
  "destination" : {
    "address" : "address",
    "keywords" : "keywords",
    "cityCode" : "cityCode",
    "coordinates" : {
      "latitude" : 5.962134,
      "longitude" : 5.637377
    }
  },
  "packages" : "",
  "quotes" : [ {
    "amount" : 6,
    "distance" : 1,
    "service" : {
      "name" : "name",
      "id" : 0
    },
    "estimatedTimeline" : {
      "create" : { }
    }
  }, {
    "amount" : 6,
    "distance" : 1,
    "service" : {
      "name" : "name",
      "id" : 0
    },
    "estimatedTimeline" : {
      "create" : { }
    }
  } ]
};
    if (Object.keys(examples).length > 0) {
      resolve(examples[Object.keys(examples)[0]]);
    } else {
      resolve();
    }
  });
}

